<?php
$conn = new mysqli("localhost", "cbymewng_pass_gsmserver_org", "7NLVGRYndWkBzUxBkGyC", "cbymewng_pass_gsmserver_org");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
