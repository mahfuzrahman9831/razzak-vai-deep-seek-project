<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header('Location: a_a_admin.php');
    exit();
}
include 'db.php';

// Toggle status
if (isset($_GET['toggle_id'])) {
    $id = (int)$_GET['toggle_id'];
    $stmt = $conn->prepare("SELECT status FROM files WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $res = $stmt->get_result();
    if ($row = $res->fetch_assoc()) {
        $newStatus = $row['status'] === 'Active' ? 'Inactive' : 'Active';
        $u = $conn->prepare("UPDATE files SET status = ? WHERE id = ?");
        $u->bind_param("si", $newStatus, $id);
        $u->execute();
        
        $_SESSION['alert'] = [
            'type' => 'success',
            'title' => $newStatus === 'Active' ? 'Activated Successfully!' : 'Deactivated Successfully!',
            'text' => 'The firmware status has been updated.',
            'draggable' => true
        ];
    }
    header('Location: firmware_list.php');
    exit();
}

// Delete
if (isset($_GET['delete_id'])) {
    $id = (int)$_GET['delete_id'];
    $d = $conn->prepare("DELETE FROM files WHERE id = ?");
    $d->bind_param("i", $id);
    $d->execute();
    
    $_SESSION['alert'] = [
        'type' => 'success',
        'title' => 'Deleted!',
        'text' => 'The firmware has been deleted.',
        'draggable' => true
    ];
    
    header('Location: firmware_list.php');
    exit();
}

// Pagination
$limit = 10;
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$page = max($page, 1);
$offset = ($page - 1) * $limit;
$totalRows = $conn->query("SELECT COUNT(*) as total FROM files")->fetch_assoc()['total'];
$totalPages = ceil($totalRows / $limit);
$result = $conn->query("SELECT * FROM files ORDER BY id DESC LIMIT $offset, $limit");
?>
<!DOCTYPE html>
<html>
<head>
    <title>Firmware List</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
    <style>
        :root {
            --sidebar-width: 220px;
            --sidebar-bg: #2f3e47;
            --sidebar-header-bg: #1b252b;
            --sidebar-hover: #1b252b;
            --sidebar-active: #3498db;
            --topbar-bg: #3498db;
            --card-shadow: 0 4px 10px rgba(0,0,0,0.05);
            --table-header-bg: #f8f9fa;
            --table-row-hover: #f9f9f9;
            --table-border: #eee;
            --active-color: #28a745;
            --inactive-color: #dc3545;
        }
        
        body {
            margin: 0;
            font-family: "Segoe UI", sans-serif;
            background: #f5f7fa;
            min-height: 100vh;
            overflow-x: hidden;
        }
        
        /* Sidebar Styles */
        .sidebar {
            width: var(--sidebar-width);
            background: var(--sidebar-bg);
            color: white;
            height: 100vh;
            position: fixed;
            top: 0;
            left: 0;
            z-index: 1000;
            transition: all 0.3s ease;
            overflow-y: auto;
            box-shadow: 2px 0 5px rgba(0,0,0,0.1);
        }
        
        .sidebar h2 {
            text-align: center;
            padding: 20px 0;
            background: var(--sidebar-header-bg);
            margin: 0;
            font-size: 1.2rem;
            position: sticky;
            top: 0;
            z-index: 1;
        }
        
        .sidebar ul {
            list-style-type: none;
            padding: 0;
            margin: 0;
        }
        
        .sidebar ul li {
            padding: 12px 20px;
            border-bottom: 1px solid rgba(255,255,255,0.1);
            transition: all 0.3s;
        }
        
        .sidebar ul li a {
            color: white;
            text-decoration: none;
            display: flex;
            align-items: center;
        }
        
        .sidebar ul li a i {
            margin-right: 10px;
            width: 20px;
            text-align: center;
            font-size: 1.1rem;
        }
        
        .sidebar ul li:hover {
            background: var(--sidebar-hover);
        }
        
        .sidebar ul li.active {
            background: var(--sidebar-active);
        }
        
        /* Mobile Toggle Button */
        .sidebar-toggle {
            display: none;
            position: fixed;
            top: 15px;
            left: 15px;
            z-index: 1100;
            background: var(--topbar-bg);
            color: white;
            border: none;
            width: 40px;
            height: 40px;
            border-radius: 50%;
            font-size: 20px;
            cursor: pointer;
            box-shadow: 0 2px 5px rgba(0,0,0,0.2);
        }
        
        /* Topbar Styles */
        .topbar {
            height: 60px;
            background: var(--topbar-bg);
            color: white;
            margin-left: var(--sidebar-width);
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0 20px;
            position: sticky;
            top: 0;
            z-index: 900;
            transition: all 0.3s;
        }
        
        /* Content Area */
        .content {
            margin-left: var(--sidebar-width);
            padding: 20px;
            transition: all 0.3s;
        }
        
        /* Table-specific styles */
        .table-container {
            margin-top: 20px;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: var(--card-shadow);
        }
        
        #firmwareTable {
            width: 100%;
            border-collapse: separate;
            border-spacing: 0;
            background: white;
        }
        
        #firmwareTable thead th {
            background-color: var(--table-header-bg);
            padding: 12px 15px;
            text-align: left;
            font-weight: 600;
            border-bottom: 2px solid var(--table-border);
            position: sticky;
            top: 0;
        }
        
        #firmwareTable tbody td {
            padding: 12px 15px;
            border-bottom: 1px solid var(--table-border);
            vertical-align: middle;
        }
        
        #firmwareTable tbody tr:last-child td {
            border-bottom: none;
        }
        
        #firmwareTable tbody tr:hover {
            background-color: var(--table-row-hover);
        }
        
        .status-badge {
            font-weight: 600;
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 0.85rem;
        }
        
        .status-active {
            background-color: rgba(40, 167, 69, 0.1);
            color: var(--active-color);
        }
        
        .status-inactive {
            background-color: rgba(220, 53, 69, 0.1);
            color: var(--inactive-color);
        }
        
        .action-buttons {
            display: flex;
            gap: 8px;
            flex-wrap: wrap;
        }
        
        .action-btn {
            padding: 6px 12px;
            font-size: 0.85rem;
            border-radius: 4px;
            display: inline-flex;
            align-items: center;
            gap: 5px;
            text-decoration: none;
            transition: all 0.2s;
        }
        
        .action-btn i {
            font-size: 0.9rem;
        }
        
        .toggle-btn {
            background-color: #ffc107;
            color: #212529;
            border: 1px solid #ffc107;
        }
        
        .toggle-btn:hover {
            background-color: #e0a800;
            border-color: #d39e00;
        }
        
        .delete-btn {
            background-color: #dc3545;
            color: white;
            border: 1px solid #dc3545;
        }
        
        .delete-btn:hover {
            background-color: #c82333;
            border-color: #bd2130;
        }
        
        /* Responsive Styles */
        @media (max-width: 992px) {
            .sidebar {
                transform: translateX(-100%);
            }
            
            .sidebar.active {
                transform: translateX(0);
            }
            
            .topbar, .content {
                margin-left: 0;
            }
            
            .sidebar-toggle {
                display: block;
            }
        }
        
        @media (max-width: 768px) {
            #firmwareTable {
                display: block;
                width: 100%;
            }
            
            #firmwareTable thead {
                display: none;
            }
            
            #firmwareTable tbody, 
            #firmwareTable tr, 
            #firmwareTable td {
                display: block;
                width: 100%;
            }
            
            #firmwareTable tr {
                margin-bottom: 15px;
                border-radius: 8px;
                overflow: hidden;
                box-shadow: 0 2px 5px rgba(0,0,0,0.1);
                position: relative;
            }
            
            #firmwareTable td {
                padding: 10px 15px;
                text-align: right;
                position: relative;
                padding-left: 50%;
            }
            
            #firmwareTable td::before {
                content: attr(data-label);
                position: absolute;
                left: 15px;
                width: 45%;
                padding-right: 10px;
                font-weight: 600;
                text-align: left;
            }
            
            .action-buttons {
                justify-content: flex-end;
            }
        }
        
        @media (max-width: 576px) {
            .content {
                padding: 15px;
            }
            
            #firmwareTable td {
                padding-left: 40%;
            }
            
            #firmwareTable td::before {
                width: 35%;
            }
            
            .action-btn {
                padding: 5px 8px;
                font-size: 0.8rem;
            }
            
            .sidebar {
                width: 80%;
            }
        }
    </style>
</head>
<body>

<!-- Mobile Toggle Button -->
<button class="sidebar-toggle" id="sidebarToggle">
    <i class="fas fa-bars"></i>
</button>

<!-- Sidebar -->
<div class="sidebar" id="sidebar">
    <h2>Admin Panel</h2>
    <ul>
        <li><a href="dashboard.php"><i class="fas fa-home"></i> Dashboard</a></li>
        <li><a href="add_file.php"><i class="fas fa-file-upload"></i> Add Firmware</a></li>
        <li class="active"><a href="firmware_list.php"><i class="fas fa-list"></i> Firmware List</a></li>
        <li><a href="add_client.php"><i class="fas fa-user-plus"></i> Add Client</a></li>
        <li><a href="client_list.php"><i class="fas fa-users"></i> Manage Client</a></li>
        <li><a href="account_manage.php"><i class="fas fa-cogs"></i> Account Manage</a></li>
        <li><a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
    </ul>
</div>

<!-- Topbar -->
<div class="topbar">
    <div>---------------- Firmware List--------------</div>
    <div><i class="fas fa-user-shield"></i> <?= htmlspecialchars($_SESSION['admin']); ?></div>
</div>

<!-- Main Content -->
<div class="content">
    <div class="section">
        <h2><i class="fas fa-microchip"></i> Firmware Files</h2>

        <div class="search-box">
            <input type="text" id="searchInput" onkeyup="searchFirmware()" placeholder="Search firmware..." class="form-control">
        </div>

        <div class="table-container">
            <table id="firmwareTable">
                <thead>
                    <tr>
                        <th>S.No</th>
                        <th>File ID</th>
                        <th>File Name</th>
                        <th>Password</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $serial = $offset + 1;
                    while ($row = $result->fetch_assoc()):
                        $statusClass = $row['status'] === 'Active' ? 'status-active' : 'status-inactive';
                    ?>
                    <tr>
                        <td data-label="S.No"><?= $serial++; ?></td>
                        <td data-label="File ID"><?= htmlspecialchars($row['file_id']); ?></td>
                        <td data-label="File Name"><?= htmlspecialchars($row['file_name']); ?></td>
                        <td data-label="Password"><?= htmlspecialchars($row['password']); ?></td>
                        <td data-label="Status">
                            <span class="status-badge <?= $statusClass; ?>"><?= $row['status']; ?></span>
                        </td>
                        <td data-label="Actions">
                            <div class="action-buttons">
                                <a href="?toggle_id=<?= $row['id']; ?>" 
                                   class="action-btn toggle-btn">
                                   <i class="fas fa-power-off"></i>
                                   <?= $row['status'] === 'Active' ? 'Deactivate' : 'Activate'; ?>
                                </a>
                                <a href="#" 
                                   onclick="confirmDelete(<?= $row['id']; ?>)" 
                                   class="action-btn delete-btn">
                                   <i class="fas fa-trash-alt"></i>
                                   Delete
                                </a>
                            </div>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>

        <?php if ($totalPages > 1): ?>
        <div class="pagination mt-4">
            <?php if ($page > 1): ?>
                <a href="?page=<?= $page - 1; ?>" class="btn btn-outline-primary">Previous</a>
            <?php endif; ?>
            
            <div class="btn-group mx-2">
            <?php 
            // Show page numbers
            $start = max(1, $page - 2);
            $end = min($totalPages, $page + 2);
            
            for ($i = $start; $i <= $end; $i++): ?>
                <a href="?page=<?= $i; ?>" class="btn <?= $page === $i ? 'btn-primary' : 'btn-outline-primary' ?>"><?= $i; ?></a>
            <?php endfor; ?>
            </div>
            
            <?php if ($page < $totalPages): ?>
                <a href="?page=<?= $page + 1; ?>" class="btn btn-outline-primary">Next</a>
            <?php endif; ?>
        </div>
        <?php endif; ?>
    </div>
</div>

<!-- JavaScript -->
<script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.js"></script>

<script>
    // Mobile sidebar toggle
    $(document).ready(function() {
        $('#sidebarToggle').click(function(e) {
            e.stopPropagation();
            $('#sidebar').toggleClass('active');
        });
        
        // Close sidebar when clicking outside
        $(document).click(function(e) {
            if ($(window).width() <= 992) {
                if (!$(e.target).closest('#sidebar').length && !$(e.target).is('#sidebarToggle')) {
                    $('#sidebar').removeClass('active');
                }
            }
        });
        
        // Close sidebar when a menu item is clicked on mobile
        $('.sidebar a').click(function() {
            if ($(window).width() <= 992) {
                $('#sidebar').removeClass('active');
            }
        });
        
        // Show alert if exists
        <?php if (isset($_SESSION['alert'])): ?>
            Swal.fire({
                title: "<?= $_SESSION['alert']['title']; ?>",
                text: "<?= $_SESSION['alert']['text']; ?>",
                icon: "<?= $_SESSION['alert']['type']; ?>",
                draggable: <?= $_SESSION['alert']['draggable'] ? 'true' : 'false'; ?>
            });
            <?php unset($_SESSION['alert']); ?>
        <?php endif; ?>
    });
    
    function searchFirmware() {
        const input = document.getElementById("searchInput").value.toLowerCase();
        const rows = document.querySelectorAll("#firmwareTable tbody tr");
        
        rows.forEach(row => {
            const text = row.textContent.toLowerCase();
            row.style.display = text.includes(input) ? "" : "none";
        });
    }
    
    function confirmDelete(id) {
        Swal.fire({
            title: "Are you sure?",
            text: "You won't be able to revert this!",
            icon: "warning",
            showCancelButton: true,
            confirmButtonColor: "#3085d6",
            cancelButtonColor: "#d33",
            confirmButtonText: "Yes, delete it!"
        }).then((result) => {
            if (result.isConfirmed) {
                window.location.href = "?delete_id=" + id;
            }
        });
    }
</script>

</body>
</html>