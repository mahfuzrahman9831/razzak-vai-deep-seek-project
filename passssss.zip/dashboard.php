<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header('Location: a_a_admin.php');
    exit();
}
include 'db.php';

// Get client statistics
$totalClientsResult = $conn->query("SELECT COUNT(*) AS total FROM clients");
$totalClients = $totalClientsResult->fetch_assoc()['total'];

$activeClientsResult = $conn->query("SELECT COUNT(*) AS active FROM clients WHERE status = 'Active'");
$activeClients = $activeClientsResult->fetch_assoc()['active'];

$inactiveClientsResult = $conn->query("SELECT COUNT(*) AS inactive FROM clients WHERE status = 'Inactive'");
$inactiveClients = $inactiveClientsResult->fetch_assoc()['inactive'];

// Get firmware statistics
$totalFirmwareResult = $conn->query("SELECT COUNT(*) AS total FROM files");
$totalFirmware = $totalFirmwareResult->fetch_assoc()['total'];

$activeFirmwareResult = $conn->query("SELECT COUNT(*) AS active FROM files WHERE status = 'Active'");
$activeFirmware = $activeFirmwareResult->fetch_assoc()['active'];

$inactiveFirmwareResult = $conn->query("SELECT COUNT(*) AS inactive FROM files WHERE status = 'Inactive'");
$inactiveFirmware = $inactiveFirmwareResult->fetch_assoc()['inactive'];
?>
<!DOCTYPE html>
<html>
<head>
    <title>Admin Dashboard</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --sidebar-width: 220px;
            --sidebar-bg: #2f3e47;
            --sidebar-header-bg: #1b252b;
            --sidebar-hover: #1b252b;
            --sidebar-active: #3498db;
            --topbar-bg: #3498db;
            --card-hover: translateY(-5px);
        }
        
        body {
            margin: 0;
            font-family: "Segoe UI", sans-serif;
            background: #f5f7fa;
            min-height: 100vh;
        }
        
        /* Sidebar Styles */
        .sidebar {
            width: var(--sidebar-width);
            background: var(--sidebar-bg);
            color: white;
            height: 100vh;
            position: fixed;
            top: 0;
            left: 0;
            z-index: 1000;
            transition: all 0.3s;
            overflow-y: auto;
        }
        
        .sidebar h2 {
            text-align: center;
            padding: 20px 0;
            background: var(--sidebar-header-bg);
            margin: 0;
            font-size: 1.2rem;
            position: sticky;
            top: 0;
        }
        
        .sidebar ul {
            list-style-type: none;
            padding: 0;
            margin: 0;
        }
        
        .sidebar ul li {
            padding: 12px 20px;
            border-bottom: 1px solid rgba(255,255,255,0.1);
            transition: all 0.3s;
        }
        
        .sidebar ul li a {
            color: white;
            text-decoration: none;
            display: block;
        }
        
        .sidebar ul li a i {
            margin-right: 10px;
            width: 20px;
            text-align: center;
        }
        
        .sidebar ul li:hover {
            background: var(--sidebar-hover);
        }
        
        .sidebar ul li.active {
            background: var(--sidebar-active);
        }
        
        /* Mobile Toggle Button */
        .sidebar-toggle {
            display: none;
            position: fixed;
            top: 10px;
            left: 10px;
            z-index: 1100;
            background: var(--topbar-bg);
            color: white;
            border: none;
            width: 40px;
            height: 40px;
            border-radius: 50%;
            font-size: 20px;
            cursor: pointer;
        }
        
        /* Topbar Styles */
        .topbar {
            height: 60px;
            background: var(--topbar-bg);
            color: white;
            margin-left: var(--sidebar-width);
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0 20px;
            position: sticky;
            top: 0;
            z-index: 900;
            transition: all 0.3s;
        }
        
        /* Content Area */
        .content {
            margin-left: var(--sidebar-width);
            padding: 20px;
            transition: all 0.3s;
        }
        
        /* Dashboard Grid */
        .grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-top: 20px;
        }
        
        .card {
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.05);
            text-align: center;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }
        
        .card:hover {
            transform: var(--card-hover);
            box-shadow: 0 6px 12px rgba(0,0,0,0.1);
        }
        
        .card i {
            font-size: 30px;
            margin-bottom: 10px;
            color: var(--topbar-bg);
        }
        
        .card a {
            text-decoration: none;
            color: #333;
            display: block;
            font-size: 18px;
        }
        
        /* Footer */
        .footer {
            margin-left: var(--sidebar-width);
            padding: 20px;
            text-align: center;
            font-size: 14px;
            color: #777;
            transition: all 0.3s;
        }
        
        /* Responsive Styles */
        @media (max-width: 768px) {
            .sidebar {
                left: -100%;
            }
            
            .sidebar.active {
                left: 0;
                width: 80%;
                max-width: 300px;
            }
            
            .topbar, .content, .footer {
                margin-left: 0;
            }
            
            .sidebar-toggle {
                display: block;
            }
            
            .grid {
                grid-template-columns: repeat(2, 1fr);
            }
        }
        
        @media (max-width: 576px) {
            .content {
                padding: 15px;
            }
            
            .grid {
                grid-template-columns: 1fr;
            }
            
            .card {
                padding: 15px;
            }
        }
    </style>
</head>
<body>

<!-- Mobile Toggle Button -->
<button class="sidebar-toggle" id="sidebarToggle">
    <i class="fas fa-bars"></i>
</button>

<!-- Sidebar -->
<div class="sidebar" id="sidebar">
    <h2>Admin Panel</h2>
    <ul>
        <li class="active"><a href="dashboard.php"><i class="fas fa-home"></i> Dashboard</a></li>
        <li><a href="add_file.php"><i class="fas fa-file-upload"></i> Add Firmware</a></li>
        <li><a href="firmware_list.php"><i class="fas fa-list"></i> Firmware List</a></li>
        <li><a href="add_client.php"><i class="fas fa-user-plus"></i> Add Client</a></li>
        <li><a href="client_list.php"><i class="fas fa-users"></i> Manage Client</a></li>
        <li><a href="account_manage.php"><i class="fas fa-cogs"></i> Account Manage</a></li>
        <li><a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
    </ul>
</div>

<!-- Topbar -->
<div class="topbar">
    <div>------------GSMSERVER.ORG Dashboard-------</div>
    <div><i class="fas fa-user-shield"></i> <?= htmlspecialchars($_SESSION['admin']); ?></div>
</div>

<!-- Main Content -->
<div class="content">
    <h2>Dashboard Overview</h2>
    <div class="grid">
        <!-- Client Stats -->
        <div class="card">
            <i class="fas fa-users"></i>
            <a href="client_list.php">Total Clients: <?= $totalClients ?></a>
        </div>
        <div class="card">
            <i class="fas fa-user-check"></i>
            <a href="client_list.php">Active Clients: <?= $activeClients ?></a>
        </div>
        <div class="card">
            <i class="fas fa-user-times"></i>
            <a href="client_list.php">Inactive Clients: <?= $inactiveClients ?></a>
        </div>

        <!-- Firmware Stats -->
        <div class="card">
            <i class="fas fa-file-alt"></i>
            <a href="firmware_list.php">Total Firmware: <?= $totalFirmware ?></a>
        </div>
        <div class="card">
            <i class="fas fa-check-circle"></i>
            <a href="firmware_list.php">Active Firmware: <?= $activeFirmware ?></a>
        </div>
        <div class="card">
            <i class="fas fa-times-circle"></i>
            <a href="firmware_list.php">Inactive Firmware: <?= $inactiveFirmware ?></a>
        </div>
    </div>
</div>

<!-- Footer -->
<div class="footer">
    &copy; <?= date("Y"); ?> Admin Dashboard. All rights reserved.
</div>

<!-- JavaScript -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
    $(document).ready(function() {
        // Mobile sidebar toggle
        $('#sidebarToggle').click(function() {
            $('#sidebar').toggleClass('active');
        });
        
        // Close sidebar when clicking outside on mobile
        $(document).click(function(e) {
            if ($(window).width() <= 768) {
                if (!$(e.target).closest('#sidebar, #sidebarToggle').length) {
                    $('#sidebar').removeClass('active');
                }
            }
        });
    });
</script>

</body>
</html>